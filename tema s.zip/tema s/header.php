<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" xmlns:og="http://opengraphprotocol.org/schema/" xmlns:fb="http://www.facebook.com/2008/fbml">
<head>
 
<title><?php bloginfo('name') ?></title>
 <link rel='stylesheet' <?php bloginfo('stylesheet_url'); ?> type= 'txt/css' href = 'estilos.css' media = 'all'/> 
 <?php wp_head(); ?>
 </head>
<div class = "perfil">
		
		<div id = "foto"></div>
		<div id = "descricao">
		<p id="blogtitulo"><?php bloginfo('name') ?></p>
		<p><?php bloginfo('description'); ?></p>
		</div>
		<?php wp_list_pages('title_li='); ?>
		<div class="link1"><a href ="####">link 1</a></div>
		<div class="link1"><a href ="####">link 2</a></div>
		<div class="link1"><a href ="####">link 3</a></div>
		
		</div>