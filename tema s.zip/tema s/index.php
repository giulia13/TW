<?php get_header(); ?>
<?php
	if(have_posts()) : while(have_posts()) : the_post();
?>

</div>
		
		<div id= "post">
			<p id= "titulopost"><a href="<?php the_permalink() ?>" rel="bookmark"><?php the_title(); ?></a></p>
			<p id = "texto"><?php the_content(); ?></p>
			
			<p class ="parti"><a href="##">comente</a></p>
			<p class ="parti"><a href="###">compartilhe</a></p>
		</div>
<?php endwhile; else: ?>
<p><?php _e('Nenhum post encontrado.'); ?></p>
<?php endif; ?>
		
